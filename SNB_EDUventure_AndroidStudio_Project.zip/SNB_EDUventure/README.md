# SNB EDUventure - Android Studio Project

## Quick Start
1. Open Android Studio (Ladybug / Meerkat or newer).
2. Choose "Open" and select this folder.
3. Allow Gradle 9.1.0 and AGP 9.0.1 to sync.
4. Run on an Android device or emulator (minSdk 24, targetSdk 36).

## Privacy Guarantee
- Zero telemetry, zero analytics, zero trackers.
- Only https://snbhojai.com is accessed.
