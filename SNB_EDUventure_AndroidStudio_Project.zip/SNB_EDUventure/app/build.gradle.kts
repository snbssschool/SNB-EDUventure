plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.snb.pkm.android"
    compileSdk = 36
    buildToolsVersion = "36.0.0"

    defaultConfig {
        applicationId = "com.snb.pkm.android"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "2.0.2.6"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug")
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs = freeCompilerArgs + listOf(
            "-opt-in=kotlin.RequiresOptIn"
        )
    }

    buildFeatures {
        viewBinding = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // Core AndroidX & Architecture
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.activity.ktx)

    // Material 3 Components (DayNight, Dynamic colors on Android 12+)
    implementation(libs.material)

    // AndroidX SplashScreen API (Modern cold-start splash without deprecated splash activity)
    implementation(libs.androidx.core.splashscreen)

    // AndroidX WebKit for hardened modern WebView APIs
    implementation(libs.androidx.webkit)

    // SwipeRefreshLayout for smooth pull-to-refresh
    implementation(libs.androidx.swiperefreshlayout)

    // RootBeer: Local offline heuristic root detection (FOSS Apache 2.0, zero telemetry, no network calls)
    implementation(libs.rootbeer.lib)

    // ZERO third-party SDKs: No Firebase, No Play Services, No Crashlytics, No AdMob, No Analytics
}