package com.snb.pkm.android.security

import android.app.Activity
import android.content.Context
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.scottyab.rootbeer.RootBeer
import com.snb.pkm.android.R

/**
 * Local-only Root and Tamper Detection for SNB EDUventure.
 *
 * SafetyNet Attestation was deprecated in 2022 and shut down in January 2025.
 * Play Integrity API is deliberately omitted because it requires Google Play Services
 * and transmits device telemetry.
 *
 * RootBeer (com.scottyab:rootbeer-lib:0.1.2) is Apache 2.0, completely offline,
 * and executes local heuristic checks only.
 */
object RootTamperChecker {

    fun isDeviceTampered(context: Context): Boolean {
        return try {
            val rootBeer = RootBeer(context)
            rootBeer.isRooted ||
                    rootBeer.isRootedWithBusyBoxCheck ||
                    rootBeer.detectTestKeys() ||
                    rootBeer.detectRootManagementApps() ||
                    rootBeer.detectPotentiallyDangerousApps()
        } catch (_: Exception) {
            false
        }
    }

    fun showTamperDialogAndHalt(activity: Activity) {
        val dialog = MaterialAlertDialogBuilder(activity)
            .setTitle(R.string.security_alert_title)
            .setMessage(R.string.security_alert_message)
            .setIcon(android.R.drawable.ic_dialog_alert)
            .setCancelable(false)
            .setPositiveButton(R.string.security_alert_close) { _, _ ->
                activity.finishAndRemoveTask()
            }
            .create()

        dialog.setCanceledOnTouchOutside(false)
        dialog.show()
    }
}