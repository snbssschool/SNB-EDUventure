package com.snb.pkm.android.cache

import android.content.Context
import android.webkit.WebResourceResponse
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.*
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Hand-rolled, thread-safe on-disk LRU cache for web images.
 *
 * Design choices & dependency rationale:
 * 1. Why avoid JakeWharton/DiskLruCache?
 *    The repository JakeWharton/DiskLruCache was archived in 2023 and is unmaintained.
 *    Hand-rolling this self-contained class avoids stale abandoned binaries and third-party bloat.
 * 2. Capped at 500 MB (524,288,000 bytes). Evicts least-recently-used entries when capacity is reached.
 * 3. Stored in context.cacheDir/snb_image_cache (safe app-private storage, no permissions needed).
 * 4. Thread-safe: operates off the main thread within WebViewClient.shouldInterceptRequest.
 * 5. Respects Cache-Control / ETag headers; falls back to 30 days maximum freshness.
 */
class DiskLruCache(context: Context) {

    private val cacheDir: File = File(context.cacheDir, "snb_image_cache").apply {
        if (!exists()) mkdirs()
    }

    private val journalFile: File = File(cacheDir, "journal.tsv")
    private val lock = ReentrantLock()

    private val entries = LinkedHashMap<String, CacheEntry>(64, 0.75f, true)
    private var currentSize: Long = 0

    companion object {
        const val MAX_CACHE_SIZE_BYTES: Long = 524_288_000L // 500 MB
        private const val DEFAULT_MAX_AGE_MS: Long = 30L * 24 * 60 * 60 * 1000 // 30 Days

        private val IMAGE_EXTENSIONS = setOf(
            "jpg", "jpeg", "png", "webp", "gif", "svg", "ico"
        )

        fun isImageRequest(url: String): Boolean {
            val cleanUrl = url.substringBefore('?').substringBefore('#').lowercase(Locale.ROOT)
            return IMAGE_EXTENSIONS.any { cleanUrl.endsWith(".$it") }
        }

        fun getMimeType(url: String): String {
            val cleanUrl = url.substringBefore('?').substringBefore('#').lowercase(Locale.ROOT)
            return when {
                cleanUrl.endsWith(".png") -> "image/png"
                cleanUrl.endsWith(".jpg") || cleanUrl.endsWith(".jpeg") -> "image/jpeg"
                cleanUrl.endsWith(".webp") -> "image/webp"
                cleanUrl.endsWith(".gif") -> "image/gif"
                cleanUrl.endsWith(".svg") -> "image/svg+xml"
                cleanUrl.endsWith(".ico") -> "image/x-icon"
                else -> "image/*"
            }
        }
    }

    data class CacheEntry(
        val key: String,
        val fileName: String,
        val size: Long,
        var lastAccessed: Long,
        val expiryTime: Long,
        val eTag: String?,
        val mimeType: String
    )

    init {
        loadJournal()
    }

    fun getOrFetch(url: String): WebResourceResponse? {
        val key = hashKey(url)
        val mimeType = getMimeType(url)

        lock.withLock {
            val entry = entries[key]
            if (entry != null) {
                val file = File(cacheDir, entry.fileName)
                val now = System.currentTimeMillis()
                if (file.exists() && entry.expiryTime > now) {
                    entry.lastAccessed = now
                    try {
                        val responseHeaders = mutableMapOf(
                            "Cache-Control" to "max-age=2592000",
                            "Access-Control-Allow-Origin" to "*"
                        )
                        entry.eTag?.let { responseHeaders["ETag"] = it }

                        return WebResourceResponse(
                            entry.mimeType.ifBlank { mimeType },
                            "UTF-8",
                            200,
                            "OK",
                            responseHeaders,
                            FileInputStream(file)
                        )
                    } catch (_: Exception) {}
                }
            }
        }

        return try {
            val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10000
                readTimeout = 15000
                instanceFollowRedirects = true
                requestMethod = "GET"
                setRequestProperty("User-Agent", "SNB-EDUventure-Client")
            }

            connection.connect()
            if (connection.responseCode != HttpURLConnection.HTTP_OK) return null

            val contentType = connection.contentType ?: mimeType
            val eTag = connection.getHeaderField("ETag")
            val cacheControl = connection.getHeaderField("Cache-Control")
            val maxAgeMs = parseCacheControlMaxAge(cacheControl) ?: DEFAULT_MAX_AGE_MS
            val expiry = System.currentTimeMillis() + maxAgeMs

            val tempFile = File(cacheDir, "${key}.tmp")
            val targetFile = File(cacheDir, "${key}.dat")

            connection.inputStream.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            }

            if (tempFile.renameTo(targetFile)) {
                val fileSize = targetFile.length()
                val entry = CacheEntry(
                    key = key,
                    fileName = targetFile.name,
                    size = fileSize,
                    lastAccessed = System.currentTimeMillis(),
                    expiryTime = expiry,
                    eTag = eTag,
                    mimeType = contentType
                )

                lock.withLock {
                    entries[key] = entry
                    currentSize += fileSize
                    evictIfNeeded()
                    saveJournal()
                }

                WebResourceResponse(
                    contentType,
                    "UTF-8",
                    200,
                    "OK",
                    mapOf("Access-Control-Allow-Origin" to "*"),
                    FileInputStream(targetFile)
                )
            } else {
                tempFile.delete()
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun evictIfNeeded() {
        while (currentSize > MAX_CACHE_SIZE_BYTES && entries.isNotEmpty()) {
            val oldestKey = entries.keys.firstOrNull() ?: break
            val removed = entries.remove(oldestKey)
            if (removed != null) {
                val file = File(cacheDir, removed.fileName)
                if (file.exists() && file.delete()) {
                    currentSize -= removed.size
                }
            }
        }
    }

    fun clearCache() {
        lock.withLock {
            entries.clear()
            currentSize = 0
            cacheDir.listFiles()?.forEach { it.delete() }
        }
    }

    private fun loadJournal() {
        lock.withLock {
            entries.clear()
            currentSize = 0
            if (!journalFile.exists()) return

            try {
                journalFile.forEachLine { line ->
                    val tokens = line.split("\t")
                    if (tokens.size >= 7) {
                        val key = tokens[0]
                        val fileName = tokens[1]
                        val size = tokens[2].toLongOrNull() ?: 0L
                        val lastAccessed = tokens[3].toLongOrNull() ?: 0L
                        val expiryTime = tokens[4].toLongOrNull() ?: 0L
                        val eTag = tokens[5].takeIf { it != "null" }
                        val mime = tokens[6]

                        val file = File(cacheDir, fileName)
                        if (file.exists()) {
                            entries[key] = CacheEntry(key, fileName, size, lastAccessed, expiryTime, eTag, mime)
                            currentSize += size
                        }
                    }
                }
            } catch (_: Exception) {
                clearCache()
            }
        }
    }

    private fun saveJournal() {
        try {
            val tempJournal = File(cacheDir, "journal.tmp")
            BufferedWriter(FileWriter(tempJournal)).use { writer ->
                entries.values.forEach { e ->
                    writer.write("${e.key}\t${e.fileName}\t${e.size}\t${e.lastAccessed}\t${e.expiryTime}\t${e.eTag ?: "null"}\t${e.mimeType}\n")
                }
            }
            tempJournal.renameTo(journalFile)
        } catch (_: Exception) {}
    }

    private fun parseCacheControlMaxAge(header: String?): Long? {
        if (header == null) return null
        val match = Regex("max-age=(\\d+)").find(header) ?: return null
        val seconds = match.groupValues[1].toLongOrNull() ?: return null
        return seconds * 1000
    }

    private fun hashKey(url: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val bytes = md.digest(url.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}