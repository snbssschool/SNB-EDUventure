package com.snb.pkm.android.ui

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.view.View
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.snb.pkm.android.R

class StatusBarScrimView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var currentColor: Int = Color.TRANSPARENT
    private var baseColor: Int = Color.TRANSPARENT
    private var colorAnimator: ValueAnimator? = null
    private var insetsController: WindowInsetsControllerCompat? = null

    init {
        baseColor = context.getColor(R.color.brand_primary)
        currentColor = baseColor
        setBackgroundColor(currentColor)

        ViewCompat.setOnApplyWindowInsetsListener(this) { view, insets ->
            val statusBarHeight = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.layoutParams = view.layoutParams.apply {
                height = statusBarHeight
            }
            insets
        }
    }

    fun attachWindow(activity: Activity) {
        insetsController = WindowInsetsControllerCompat(activity.window, this)
        updateIconAppearance(currentColor)
    }

    fun setScrimColor(newColor: Int, animated: Boolean = true) {
        if (newColor == Color.TRANSPARENT || newColor == 0) return
        baseColor = newColor
        colorAnimator?.cancel()

        if (!animated) {
            currentColor = newColor
            setBackgroundColor(currentColor)
            updateIconAppearance(currentColor)
            return
        }

        colorAnimator = ValueAnimator.ofObject(ArgbEvaluator(), currentColor, newColor).apply {
            duration = 300L
            addUpdateListener { animator ->
                val animatedColor = animator.animatedValue as Int
                currentColor = animatedColor
                setBackgroundColor(animatedColor)
                updateIconAppearance(animatedColor)
            }
            start()
        }
    }

    fun updateScrollProgress(progressFraction: Float) {
        val clamped = progressFraction.coerceIn(0f, 1f)
        val scrollShadeColor = ColorUtils.blendARGB(baseColor, Color.BLACK, clamped * 0.18f)
        setBackgroundColor(scrollShadeColor)
    }

    private fun updateIconAppearance(color: Int) {
        val luminance = ColorUtils.calculateLuminance(color)
        insetsController?.isAppearanceLightStatusBars = (luminance > 0.5)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        colorAnimator?.cancel()
    }
}