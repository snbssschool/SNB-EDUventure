package com.snb.pkm.android

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewFeature
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.snb.pkm.android.cache.DiskLruCache
import com.snb.pkm.android.databinding.ActivityMainBinding
import com.snb.pkm.android.databinding.DialogThemeChoiceBinding
import com.snb.pkm.android.security.RootTamperChecker
import com.snb.pkm.android.utils.Messages
import com.snb.pkm.android.utils.NetworkUtils
import com.snb.pkm.android.utils.ThemeManager
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var themeManager: ThemeManager
    private lateinit var imageDiskCache: DiskLruCache
    private lateinit var assetLoader: WebViewAssetLoader

    private var defaultMobileUserAgent: String? = null
    private var customVideoView: View? = null
    private var customVideoCallback: WebChromeClient.CustomViewCallback? = null
    private var previousOrientation: Int = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null

    private val filePickerLauncher =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris != null && uris.isNotEmpty()) {
                fileUploadCallback?.onReceiveValue(uris.toTypedArray())
            } else {
                fileUploadCallback?.onReceiveValue(null)
            }
            fileUploadCallback = null
        }

    private val backPressedCallback = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            when {
                customVideoView != null -> customVideoCallback?.onCustomViewHidden()
                binding.webView.canGoBack() -> binding.webView.goBack()
                else -> showExitConfirmationDialog()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // STEP 1: Process Starts -> Root / Tamper Detection Check First
        if (RootTamperChecker.isDeviceTampered(this)) {
            RootTamperChecker.showTamperDialogAndHalt(this)
            return
        }

        // STEP 2: Show Splash Screen (androidx.core.splashscreen)
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        themeManager = ThemeManager(this)
        imageDiskCache = DiskLruCache(applicationContext)
        binding.statusBarScrim.attachWindow(this)
        onBackPressedDispatcher.addCallback(this, backPressedCallback)

        binding.offlineOverlay.setOnRetryListener {
            if (NetworkUtils.isNetworkAvailable(this)) {
                binding.offlineOverlay.hideOffline()
                binding.loadingOverlay.showLoading()
                binding.webView.reload()
            } else {
                Toast.makeText(this, "Still offline. Please check connection.", Toast.LENGTH_SHORT).show()
            }
        }

        assetLoader = WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        // STEP 3: First Launch Theme Dialog Check
        if (themeManager.isFirstLaunch()) {
            showFirstLaunchThemeDialog {
                initializeWebView(savedInstanceState)
            }
        } else {
            themeManager.applyCurrentTheme()
            initializeWebView(savedInstanceState)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun initializeWebView(savedInstanceState: Bundle?) {
        val webView = binding.webView
        val settings = webView.settings

        defaultMobileUserAgent = WebSettings.getDefaultUserAgent(this)
        applyUserAgentForOrientation(resources.configuration.orientation)

        if (Build.VERSION.SDK_INT >= 35) {
            webView.requestedFrameRate = View.REQUESTED_FRAME_RATE_CATEGORY_HIGH
            binding.swipeRefreshLayout.requestedFrameRate = View.REQUESTED_FRAME_RATE_CATEGORY_HIGH
        }

        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.allowFileAccessFromFileURLs = false
        settings.allowUniversalAccessFromFileURLs = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        settings.setGeolocationEnabled(false)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false)
        settings.mediaPlaybackRequiresUserGesture = true

        settings.setSupportZoom(true)
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true

        // Safe Browsing permanently disabled (avoids sending telemetry of visited URLs to Google)
        if (WebViewFeature.isFeatureSupported(WebViewFeature.SAFE_BROWSING_ENABLE)) {
            WebSettingsCompat.setSafeBrowsingEnabled(settings, false)
        }

        applyAlgorithmicDarkeningPreference()

        binding.swipeRefreshLayout.setColorSchemeColors(getColor(R.color.brand_primary))
        binding.swipeRefreshLayout.setOnChildScrollUpCallback { _, _ -> webView.scrollY > 0 }
        binding.swipeRefreshLayout.setOnRefreshListener { webView.reload() }

        webView.setOnScrollChangeListener { _, _, scrollY, _, _ ->
            val range = webView.computeVerticalScrollRange() - webView.computeVerticalScrollExtent()
            if (range > 0) {
                val progress = (scrollY.toFloat() / range.toFloat()).coerceIn(0f, 1f)
                binding.statusBarScrim.updateScrollProgress(progress)
            }
        }

        setupWebViewClient()
        setupWebChromeClient()
        setupDownloadListener()

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            binding.loadingOverlay.showLoading(animated = false)
            webView.loadUrl(TARGET_HOME_URL)
        }
    }

    private fun setupWebViewClient() {
        binding.webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                binding.loadingOverlay.showLoading()
                binding.offlineOverlay.hideOffline()
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                binding.swipeRefreshLayout.isRefreshing = false
                extractAndApplyThemeColor(view)
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url ?: return false
                val host = url.host?.lowercase(Locale.ROOT) ?: ""
                if (isDomainAllowed(host)) return false
                showExternalDomainConfirmationDialog(url.toString())
                return true
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val url = request?.url ?: return null
                val assetResponse = assetLoader.shouldInterceptRequest(url)
                if (assetResponse != null) return assetResponse

                val urlString = url.toString()
                if (DiskLruCache.isImageRequest(urlString)) {
                    val cachedResponse = imageDiskCache.getOrFetch(urlString)
                    if (cachedResponse != null) return cachedResponse
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    binding.loadingOverlay.hideLoading()
                    binding.offlineOverlay.showOffline()
                }
            }
        }
    }

    private fun setupWebChromeClient() {
        binding.webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                if (newProgress >= 100) binding.loadingOverlay.hideLoading()
            }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customVideoView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customVideoView = view
                customVideoCallback = callback
                previousOrientation = requestedOrientation

                binding.customViewContainer.addView(
                    view,
                    ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                )
                binding.customViewContainer.visibility = View.VISIBLE
                binding.swipeRefreshLayout.visibility = View.GONE
                binding.statusBarScrim.visibility = View.GONE
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }

            override fun onHideCustomView() {
                if (customVideoView == null) return
                binding.customViewContainer.removeView(customVideoView)
                binding.customViewContainer.visibility = View.GONE
                binding.swipeRefreshLayout.visibility = View.VISIBLE
                binding.statusBarScrim.visibility = View.VISIBLE
                customVideoView = null
                customVideoCallback = null
                requestedOrientation = previousOrientation
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback
                filePickerLauncher.launch(
                    arrayOf("application/pdf", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                )
                return true
            }
        }
    }

    private fun setupDownloadListener() {
        binding.webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val uri = Uri.parse(url)
                val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
                val request = DownloadManager.Request(uri).apply {
                    setMimeType(mimeType)
                    addRequestProperty("User-Agent", userAgent)
                    setTitle(fileName)
                    setDescription("Downloading from SNB EDUventure")
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                }
                val downloadManager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                downloadManager.enqueue(request)
                Toast.makeText(this, "Downloading: $fileName", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Download failed: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun extractAndApplyThemeColor(webView: WebView?) {
        webView?.evaluateJavascript(
            """(function() {
                var meta = document.querySelector('meta[name="theme-color"]');
                if (meta && meta.content) return meta.content;
                return window.getComputedStyle(document.body).backgroundColor || '';
            })();""".trimIndent()
        ) { result ->
            val colorStr = result?.replace(""", "")?.trim()
            val parsedColor = parseCssColor(colorStr)
            binding.statusBarScrim.setScrimColor(parsedColor ?: getColor(R.color.brand_primary))
        }
    }

    private fun parseCssColor(colorStr: String?): Int? {
        if (colorStr.isNullOrBlank()) return null
        return try {
            when {
                colorStr.startsWith("#") -> Color.parseColor(colorStr)
                colorStr.startsWith("rgb") -> {
                    val nums = colorStr.substringAfter('(').substringBefore(')').split(',').map { it.trim().toIntOrNull() ?: 0 }
                    if (nums.size >= 3) Color.rgb(nums[0], nums[1], nums[2]) else null
                }
                else -> null
            }
        } catch (_: Exception) { null }
    }

    private fun isDomainAllowed(host: String): Boolean {
        return host == "snbhojai.com" || host.endsWith(".snbhojai.com")
    }

    private fun showExternalDomainConfirmationDialog(targetUrl: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.leaving_domain_title)
            .setMessage(getString(R.string.leaving_domain_message, targetUrl))
            .setPositiveButton(R.string.action_continue) { _, _ ->
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)))
                } catch (_: Exception) {
                    Toast.makeText(this, "Unable to open external browser", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.action_cancel, null)
            .show()
    }

    private fun showExitConfirmationDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.app_name)
            .setMessage(Messages.getRandomExitMessage())
            .setPositiveButton(R.string.exit_dialog_confirm) { _, _ -> finish() }
            .setNegativeButton(R.string.exit_dialog_cancel, null)
            .show()
    }

    private fun showFirstLaunchThemeDialog(onComplete: () -> Unit) {
        val dialogBinding = DialogThemeChoiceBinding.inflate(layoutInflater)
        dialogBinding.radioThemeLight.isChecked = true

        dialogBinding.themeRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            dialogBinding.checkboxDarkenPages.isEnabled = (checkedId == R.id.radioThemeDark)
            if (checkedId == R.id.radioThemeLight) dialogBinding.checkboxDarkenPages.isChecked = false
        }

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.theme_dialog_title)
            .setView(dialogBinding.root)
            .setCancelable(false)
            .setPositiveButton(R.string.theme_dialog_continue) { _, _ ->
                val isDark = dialogBinding.radioThemeDark.isChecked
                val mode = if (isDark) ThemeManager.THEME_DARK else ThemeManager.THEME_LIGHT
                themeManager.setThemeMode(mode)
                themeManager.setDarkenPagesAllowed(dialogBinding.checkboxDarkenPages.isChecked)
                themeManager.markFirstLaunchComplete()
                onComplete()
            }
            .create()

        dialog.setCanceledOnTouchOutside(false)
        dialog.show()
    }

    private fun applyAlgorithmicDarkeningPreference() {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            val isDark = themeManager.getSavedThemeMode() == ThemeManager.THEME_DARK
            val shouldDarken = isDark && themeManager.isDarkenPagesAllowed()
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(binding.webView.settings, shouldDarken)
        }
    }

    private fun applyUserAgentForOrientation(orientation: Int) {
        val baseUa = defaultMobileUserAgent ?: return
        val settings = binding.webView.settings
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            val desktopUa = baseUa
                .replace("Mobile", "")
                .replace(Regex("Android [^;]+;"), "X11; Linux x86_64;")
            settings.userAgentString = desktopUa
        } else {
            settings.userAgentString = baseUa
        }
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyUserAgentForOrientation(newConfig.orientation)
        binding.webView.reload()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        binding.webView.saveState(outState)
    }

    override fun onDestroy() {
        super.onDestroy()
        binding.webView.destroy()
    }

    companion object {
        const val TARGET_HOME_URL = "https://snbhojai.com"
    }
}