@rem Gradle wrapper batch script
@if "%DEBUG%" == "" @echo off
gradle %*
